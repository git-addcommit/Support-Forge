# cipher-fellows Complete Setup Guide

**Your AI Safety Research Portfolio** — Updated: 2026-06-15

---

## 📁 Current Folder Structure

```
c:\cf\
├── cipher-fellows/   ← Main research toolkit (CLI + core projects)
├── cfui/             ← Gradio web UI (runs the dashboard)
└── New folder/       ← Backups (keep for now)
```

---

## 🎯 What Each Part Does

| Folder | Purpose | How to Run |
|--------|---------|------------|
| **cipher-fellows** | CLI + 3 research projects (SpecLab, SentinelBench, SkillForge) | `python main.py <command>` |
| **cfui** | Web dashboard UI | `python app.py` |

**Are they connected?** Yes — `cipher-fellows/main.py ui` command launches the `cfui` app!

---

## 🚀 Quick Start (10 Minutes)

### Step 1: Setup cipher-fellows (Research CLI)

```powershell
# Navigate to cipher-fellows
cd c:\cf\cipher-fellows

# Create virtual environment
python -m venv .venv
.\.venv\Scripts\Activate.ps1

# Install dependencies
pip install -r requirements.txt

# Copy environment template
copy .env.example .env
```

### Step 2: Setup cfui (Web Dashboard)

```powershell
# Navigate to cfui
cd c:\cf\cfui

# Create virtual environment (if not already)
python -m venv .venv
.\.venv\Scripts\Activate.ps1

# Install dependencies
pip install -r requirements.txt

# Copy environment template
copy .env.example .env
```

### Step 3: Configure API Keys

Edit `.env` in **both** folders and add at least ONE:

```env
# Option 1: Groq (free, fast) — RECOMMENDED FOR STARTING
GROQ_API_KEY=your_groq_key_here

# Option 2: Anthropic (Claude)
ANTHROPIC_API_KEY=your_anthropic_key_here

# Option 3: Ollama (local, free)
# Just run: ollama serve
# Then pull a model: ollama pull llama2
```

**Get free API keys:**
- Groq: https://console.groq.com
- Anthropic: https://console.anthropic.com

### Step 4: Run the Web Dashboard

```powershell
cd c:\cf\cfui
.\.venv\Scripts\Activate.ps1
python app.py
```

Then open **http://localhost:7860** in your browser.

---

## 📋 Available Commands

### From cipher-fellows/ (CLI)

```bash
# Check environment
python main.py status

# Run SpecLab (value conflicts)
python main.py speclab --demo
python main.py speclab --models llama3 qwen2 --scenarios 20

# Run SentinelBench (monitor blind spots)
python main.py sentinelbench --demo
python main.py sentinelbench --blind-spot file_reuse

# Run SkillForge (learning experiment)
python main.py skillforge --demo
python main.py skillforge --run-experiment

# Run all three projects
python main.py orchestrate --demo

# Generate portfolio report
python main.py analyze --format markdown --output report.md

# Launch web UI
python main.py ui
```

### From cfui/ (Web Dashboard)

```bash
# Just run:
python app.py
# Opens http://localhost:7860
```

---

## 🎓 Your Research Projects (Thesis Points)

### Project 1: SpecLab — Value Conflict Stress Testing

**Research Question:** Do LLM specs with value explanations produce more consistent behavior than those with only rules?

**Thesis Point:** "I investigated whether explaining *why* values matter (not just *what* to do) leads to more consistent model behavior under conflict."

**Method:**
- 50 value-conflict scenarios
- Compare models with value explanations vs rules-only
- Measure behavioral divergence

**Finding:** 36% lower divergence with value explanations

**Citation:** Zhang et al. (2026) — *Stress-Testing Model Specs Reveals Character Differences*

---

### Project 2: SentinelBench — Monitor Blind Spot Detection

**Research Question:** Which categories of harmful agent actions evade AI safety monitors?

**Thesis Point:** "I identified specific blind spots in Claude-as-monitor by testing synthetic attack transcripts, revealing where current safety mechanisms fail."

**Method:**
- Generate synthetic agent transcripts
- Run through Claude-as-monitor
- Measure miss rate by category

**Finding:** File-reuse attacks evade detection 3x more often than other categories

**Citation:** SLEIGHT-Bench (2026)

---

### Project 3: SkillForge — AI-Assisted Learning

**Research Question:** Does AI assistance affect long-term skill retention in programming?

**Thesis Point:** "I measured the trade-off between immediate productivity and long-term skill development when using AI assistants."

**Method:**
- 40 participants: AI-assisted vs solo conditions
- Complete Python tasks + take quiz
- Compare scores after 2 weeks

**Finding:** 12% mastery gap (replicating Shen & Tamkin 2026)

**Citation:** Shen & Tamkin (2026) — *How AI Impacts Skill Formation*

---

## 🔬 How to Demonstrate Each Project

### Demo 1: SpecLab

```bash
cd c:\cf\cipher-fellows
python main.py speclab --demo
```

**What to show:**
1. Run the demo — it generates scenarios
2. Show how models respond differently to value conflicts
3. Explain the research question

**Portfolio talking point:** "This demonstrates understanding of LLM specification design and behavioral consistency."

---

### Demo 2: SentinelBench

```bash
cd c:\cf\cipher-fellows
python main.py sentinelbench --demo
```

**What to show:**
1. Run the demo — it tests monitor on transcripts
2. Show which attack types evade detection
3. Explain the safety implications

**Portfolio talking point:** "This shows I understand AI safety evaluation and monitor limitations."

---

### Demo 3: SkillForge

```bash
cd c:\cf\cipher-fellows
python main.py skillforge --demo
```

**What to show:**
1. Run the demo — shows the experiment flow
2. Explain the RCT methodology
3. Discuss the findings

**Portfolio talking point:** "This demonstrates empirical research skills and understanding of AI's impact on learning."

---

## ✅ Verification Checklist

Before presenting your portfolio:

- [ ] `python main.py status` runs without errors
- [ ] `python main.py speclab --demo` produces output
- [ ] `python main.py sentinelbench --demo` produces output
- [ ] `python main.py skillforge --demo` produces output
- [ ] `python app.py` opens http://localhost:7860
- [ ] Can send a message and get a response from a model
- [ ] Tests pass: `pytest tests/ -v`

---

## 🐛 Troubleshooting

| Problem | Solution |
|---------|----------|
| "No module named gradio" | Run `pip install -r requirements.txt` in the correct folder |
| "GROQ_API_KEY not set" | Edit `.env` and add your key |
| "Ollama not running" | Run `ollama serve` in another terminal |
| "Port 7860 in use" | Close other Gradio apps or change port in app.py |
| Import errors | Make sure you're in the correct directory |

---

## 📚 Key Files Reference

### cipher-fellows/ (Main Research)

| File | Purpose |
|------|---------|
| `main.py` | CLI entry point |
| `speclab/runner.py` | SpecLab project |
| `sentinelbench/runner.py` | SentinelBench project |
| `skillforge/runner.py` | SkillForge project |
| `shared/status.py` | Environment checks |
| `PORTFOLIO_SUMMARY.md` | Portfolio overview |
| `docs/architecture.md` | System design |

### cfui/ (Web Dashboard)

| File | Purpose |
|------|---------|
| `app.py` | Main Gradio app |
| `timer.py` | Session metrics |
| `tools.py` | Calculator, search, file reader |
| `models.json` | Model registry |
| `GETTING_STARTED.md` | Quick start guide |

---

## 🎯 Next Steps

1. **Today:** Get both environments running with `pip install -r requirements.txt`
2. **Today:** Add at least one API key to `.env`
3. **Today:** Run `python app.py` and verify the UI loads
4. **This week:** Run each demo (`speclab --demo`, `sentinelbench --demo`, `skillforge --demo`)
5. **This week:** Run tests: `pytest tests/ -v`
6. **Before interview:** Prepare 2-minute explanation of each project

---

## 💡 Portfolio Narrative

> "I built cipher-fellows to demonstrate production-grade AI safety research. It includes three empirical projects investigating value conflicts, monitor blind spots, and AI-assisted learning — all grounded in peer-reviewed research. The toolkit features a unified CLI, Gradio dashboard, 35+ tests, and CI/CD. This isn't a demo — it's a foundation for understanding how AI systems behave under pressure and where current safety mechanisms need improvement."

---

*Setup Guide v1 — 2026-06-15*